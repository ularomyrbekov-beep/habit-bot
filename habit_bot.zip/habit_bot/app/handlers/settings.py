"""/settings: смена языка и часового пояса (используются те же callback-и, что и при онбординге)."""
from __future__ import annotations

from aiogram import F, Router
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message

from app import keyboards as kb
from app.db.models import User
from app.i18n import BILINGUAL_PICK, LANG_NAMES, t

router = Router(name="settings")


@router.message(Command("settings"))
async def cmd_settings(message: Message, state: FSMContext, user: User) -> None:
    await state.clear()
    if user.timezone is None:
        await message.answer(t(user.language, "need_start"))
        return
    text = t(user.language, "settings_menu", lang=LANG_NAMES[user.language], tz=user.timezone)
    await message.answer(text, reply_markup=kb.settings_kb(user.language))


@router.callback_query(F.data == "set:lang")
async def settings_language(cb: CallbackQuery) -> None:
    await cb.message.answer(BILINGUAL_PICK, reply_markup=kb.language_kb())
    await cb.answer()


@router.callback_query(F.data == "set:tz")
async def settings_timezone(cb: CallbackQuery, user: User) -> None:
    await cb.message.answer(t(user.language, "ask_tz"), reply_markup=kb.timezone_kb(user.language))
    await cb.answer()
