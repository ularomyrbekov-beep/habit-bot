"""/tips: готовый совет или персональный совет от ИИ-коуча."""
from __future__ import annotations

import random

from aiogram import F, Router
from aiogram.enums import ChatAction
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message
from sqlalchemy.ext.asyncio import AsyncSession

from app import keyboards as kb
from app.db.models import User
from app.i18n import TIPS, t
from app.services.coach import Coach
from app.services.context import build_user_stats

router = Router(name="tips")


def _tip_text(lang: str) -> str:
    return t(lang, "tip_header", tip=random.choice(TIPS.get(lang, TIPS["ru"])))


@router.message(Command("tips"))
async def cmd_tips(message: Message, state: FSMContext, user: User) -> None:
    await state.clear()
    await message.answer(_tip_text(user.language), reply_markup=kb.tips_kb(user.language))


@router.callback_query(F.data == "tip:more")
async def tip_more(cb: CallbackQuery, user: User) -> None:
    await cb.message.answer(_tip_text(user.language), reply_markup=kb.tips_kb(user.language))
    await cb.answer()


@router.callback_query(F.data == "tip:ai")
async def tip_ai(cb: CallbackQuery, session: AsyncSession, user: User, coach: Coach) -> None:
    lang = user.language
    await cb.answer()
    stats = await build_user_stats(session, user)
    if not stats:
        await cb.message.answer(t(lang, "tip_need_habits"))
        return
    if not coach.allow(user.id):
        await cb.message.answer(t(lang, "rate_limited"))
        return
    await cb.bot.send_chat_action(cb.message.chat.id, ChatAction.TYPING)
    answer = await coach.reply(user, stats, t(lang, "ai_tip_request"))
    await cb.message.answer(answer or t(lang, "ai_error"))
