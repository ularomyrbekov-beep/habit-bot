"""Свободный диалог с ИИ-коучем (любой текст вне команд и вне пошаговых диалогов)."""
from __future__ import annotations

from aiogram import F, Router
from aiogram.enums import ChatAction
from aiogram.filters import StateFilter
from aiogram.types import Message
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.models import User
from app.i18n import t
from app.services.coach import Coach
from app.services.context import build_user_stats
from app.services.safety import is_crisis

router = Router(name="chat")

MAX_INPUT_CHARS = 1500


@router.message(StateFilter(None), F.text, ~F.text.startswith("/"))
async def on_free_text(message: Message, session: AsyncSession, user: User, coach: Coach) -> None:
    lang = user.language
    if user.timezone is None:
        await message.answer(t(lang, "need_start"))
        return

    text = message.text[:MAX_INPUT_CHARS]

    # Признаки кризиса: обычный коучинг прекращаем, модель не вызываем
    if is_crisis(text):
        await message.answer(t(lang, "crisis"))
        return

    if not coach.allow(user.id):
        await message.answer(t(lang, "rate_limited"))
        return

    await message.bot.send_chat_action(message.chat.id, ChatAction.TYPING)
    stats = await build_user_stats(session, user)
    answer = await coach.reply(user, stats, text)
    await message.answer(answer or t(lang, "ai_error"))
