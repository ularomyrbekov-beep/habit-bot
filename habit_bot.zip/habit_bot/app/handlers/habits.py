"""/new (пошаговый диалог по одному вопросу) и /habits (список, время напоминания, удаление)."""
from __future__ import annotations

from aiogram import F, Router
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message
from sqlalchemy.ext.asyncio import AsyncSession

from app import keyboards as kb
from app.config import Settings
from app.db import repo
from app.db.models import Habit, User
from app.i18n import t
from app.services.stats import KIND_ICON
from app.states import EditHabit, NewHabit
from app.utils import clean_text, parse_time

router = Router(name="habits")

TITLE_MAX, TEXT_MAX = 100, 200


def _remind_label(lang: str, remind: str | None) -> str:
    return remind or t(lang, "remind_off")


def _rule(lang: str, kind: str, trigger: str, action: str) -> str:
    return t(lang, "rule_quit" if kind == "quit" else "rule_build", trigger=trigger, action=action)


# ---------------------------------------------------------------- /new

@router.message(Command("new"))
async def cmd_new(message: Message, state: FSMContext, session: AsyncSession, user: User, settings: Settings) -> None:
    await state.clear()
    if user.timezone is None:
        await message.answer(t(user.language, "need_start"))
        return
    if await repo.count_active_habits(session, user.id) >= settings.max_habits:
        await message.answer(t(user.language, "limit_reached", n=settings.max_habits))
        return
    await message.answer(t(user.language, "ask_kind"), reply_markup=kb.goal_kb(user.language))


@router.callback_query(F.data.startswith("kind:"))
async def on_kind(cb: CallbackQuery, state: FSMContext, session: AsyncSession, user: User, settings: Settings) -> None:
    kind = cb.data.split(":", 1)[1]
    await cb.answer()
    if kind not in ("quit", "build"):
        return
    if await repo.count_active_habits(session, user.id) >= settings.max_habits:
        await cb.message.answer(t(user.language, "limit_reached", n=settings.max_habits))
        return
    await state.clear()
    await state.set_state(NewHabit.title)
    await state.update_data(kind=kind)
    await cb.message.answer(t(user.language, f"q_title_{kind}"))


@router.message(NewHabit.title, F.text)
async def got_title(message: Message, state: FSMContext, user: User) -> None:
    text = clean_text(message.text, TITLE_MAX)
    if text is None:
        await message.answer(t(user.language, "text_bad", n=TITLE_MAX))
        return
    await state.update_data(title=text)
    kind = (await state.get_data())["kind"]
    await state.set_state(NewHabit.trigger)
    await message.answer(t(user.language, f"q_trigger_{kind}"))


@router.message(NewHabit.trigger, F.text)
async def got_trigger(message: Message, state: FSMContext, user: User) -> None:
    text = clean_text(message.text, TEXT_MAX)
    if text is None:
        await message.answer(t(user.language, "text_bad", n=TEXT_MAX))
        return
    await state.update_data(trigger=text)
    kind = (await state.get_data())["kind"]
    await state.set_state(NewHabit.action)
    await message.answer(t(user.language, f"q_action_{kind}"))


@router.message(NewHabit.action, F.text)
async def got_action(message: Message, state: FSMContext, user: User) -> None:
    text = clean_text(message.text, TEXT_MAX)
    if text is None:
        await message.answer(t(user.language, "text_bad", n=TEXT_MAX))
        return
    await state.update_data(action=text)
    await state.set_state(NewHabit.reward)
    await message.answer(t(user.language, "q_reward"), reply_markup=kb.skip_kb(user.language, "reward"))


async def _ask_remind(message: Message, state: FSMContext, user: User) -> None:
    await state.set_state(NewHabit.remind)
    await message.answer(t(user.language, "q_remind"), reply_markup=kb.time_kb(user.language))


@router.message(NewHabit.reward, F.text)
async def got_reward(message: Message, state: FSMContext, user: User) -> None:
    text = clean_text(message.text, TEXT_MAX)
    if text is None:
        await message.answer(t(user.language, "text_bad", n=TEXT_MAX))
        return
    await state.update_data(reward=text)
    await _ask_remind(message, state, user)


@router.callback_query(NewHabit.reward, F.data == "skip:reward")
async def skip_reward(cb: CallbackQuery, state: FSMContext, user: User) -> None:
    await cb.answer()
    await state.update_data(reward=None)
    await _ask_remind(cb.message, state, user)


async def _finish_new(message: Message, state: FSMContext, session: AsyncSession, user: User, remind: str | None) -> None:
    data = await state.get_data()
    if not all(k in data for k in ("kind", "title", "trigger", "action")):
        await state.clear()
        await message.answer(t(user.language, "error_generic"))
        return
    habit = await repo.create_habit(
        session,
        user_id=user.id,
        kind=data["kind"],
        title=data["title"],
        trigger=data["trigger"],
        action=data["action"],
        reward=data.get("reward"),
        remind_time=remind,
    )
    await state.clear()
    lang = user.language
    await message.answer(
        t(
            lang, "saved",
            icon=KIND_ICON[habit.kind],
            title=habit.title,
            rule=_rule(lang, habit.kind, habit.trigger, habit.action),
            reward=habit.reward or "—",
            remind=_remind_label(lang, remind),
        )
    )


@router.callback_query(NewHabit.remind, F.data.startswith("time:"))
async def new_remind_button(cb: CallbackQuery, state: FSMContext, session: AsyncSession, user: User) -> None:
    value = cb.data.split(":", 1)[1]
    await cb.answer()
    await _finish_new(cb.message, state, session, user, None if value == "off" else parse_time(value))


@router.message(NewHabit.remind, F.text)
async def new_remind_text(message: Message, state: FSMContext, session: AsyncSession, user: User) -> None:
    remind = parse_time(message.text)
    if remind is None:
        await message.answer(t(user.language, "bad_time"))
        return
    await _finish_new(message, state, session, user, remind)


# ---------------------------------------------------------------- /habits

@router.message(Command("habits"))
async def cmd_habits(message: Message, state: FSMContext, session: AsyncSession, user: User) -> None:
    await state.clear()
    habits = await repo.list_habits(session, user.id)
    if not habits:
        await message.answer(t(user.language, "no_habits"))
        return
    for h in habits:
        text = t(
            user.language, "habit_card",
            icon=KIND_ICON[h.kind], title=h.title,
            rule=_rule(user.language, h.kind, h.trigger, h.action),
            remind=_remind_label(user.language, h.remind_time),
        )
        await message.answer(text, reply_markup=kb.habit_kb(user.language, h.id))


async def _owned_habit(session: AsyncSession, user: User, callback_data: str) -> Habit | None:
    try:
        habit_id = int(callback_data.split(":", 1)[1])
    except (IndexError, ValueError):
        return None
    return await repo.get_habit(session, user.id, habit_id)


@router.callback_query(F.data.startswith("hdel:"))
async def ask_delete(cb: CallbackQuery, session: AsyncSession, user: User) -> None:
    habit = await _owned_habit(session, user, cb.data)
    if habit is None:
        await cb.answer(t(user.language, "habit_gone"), show_alert=True)
        return
    await cb.message.answer(
        t(user.language, "confirm_delete", title=habit.title),
        reply_markup=kb.confirm_delete_kb(user.language, habit.id),
    )
    await cb.answer()


@router.callback_query(F.data.startswith("hdelc:"))
async def confirm_delete(cb: CallbackQuery, session: AsyncSession, user: User) -> None:
    habit = await _owned_habit(session, user, cb.data)
    if habit is None:
        await cb.answer(t(user.language, "habit_gone"), show_alert=True)
        return
    habit.active = False  # архивируем: история чек-инов остаётся
    await cb.message.edit_text(t(user.language, "deleted"))
    await cb.answer()


@router.callback_query(F.data == "hcancel")
async def cancel_delete(cb: CallbackQuery, user: User) -> None:
    await cb.message.edit_text(t(user.language, "cancelled"))
    await cb.answer()


@router.callback_query(F.data.startswith("htime:"))
async def edit_time_start(cb: CallbackQuery, state: FSMContext, session: AsyncSession, user: User) -> None:
    habit = await _owned_habit(session, user, cb.data)
    if habit is None:
        await cb.answer(t(user.language, "habit_gone"), show_alert=True)
        return
    await state.set_state(EditHabit.time)
    await state.update_data(habit_id=habit.id)
    await cb.message.answer(t(user.language, "ask_new_time", title=habit.title), reply_markup=kb.time_kb(user.language))
    await cb.answer()


async def _apply_time(message: Message, state: FSMContext, session: AsyncSession, user: User, remind: str | None) -> None:
    data = await state.get_data()
    await state.clear()
    habit = await repo.get_habit(session, user.id, data.get("habit_id", 0))
    if habit is None:
        await message.answer(t(user.language, "habit_gone"))
        return
    habit.remind_time = remind
    habit.last_reminded = None
    await message.answer(t(user.language, "time_saved", remind=_remind_label(user.language, remind)))


@router.callback_query(EditHabit.time, F.data.startswith("time:"))
async def edit_time_button(cb: CallbackQuery, state: FSMContext, session: AsyncSession, user: User) -> None:
    value = cb.data.split(":", 1)[1]
    await cb.answer()
    await _apply_time(cb.message, state, session, user, None if value == "off" else parse_time(value))


@router.message(EditHabit.time, F.text)
async def edit_time_text(message: Message, state: FSMContext, session: AsyncSession, user: User) -> None:
    remind = parse_time(message.text)
    if remind is None:
        await message.answer(t(user.language, "bad_time"))
        return
    await _apply_time(message, state, session, user, remind)
