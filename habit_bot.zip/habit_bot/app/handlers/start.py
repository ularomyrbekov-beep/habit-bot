"""/start, онбординг (язык -> часовой пояс -> выбор цели), /cancel."""
from __future__ import annotations

from aiogram import F, Router
from aiogram.filters import Command, CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message

from app import keyboards as kb
from app.db.models import User
from app.i18n import BILINGUAL_GREETING, LANGS, t
from app.states import Onboarding
from app.utils import local_now, parse_timezone

router = Router(name="start")


@router.message(CommandStart())
async def cmd_start(message: Message, state: FSMContext, user: User) -> None:
    await state.clear()
    if user.timezone is None:  # новый пользователь: сначала язык
        await message.answer(BILINGUAL_GREETING, reply_markup=kb.language_kb())
        return
    await message.answer(t(user.language, "welcome_back"), reply_markup=kb.goal_kb(user.language))


@router.message(Command("cancel"))
async def cmd_cancel(message: Message, state: FSMContext, user: User) -> None:
    await state.clear()
    await message.answer(t(user.language, "cancelled"))


@router.callback_query(F.data.startswith("lang:"))
async def on_language(cb: CallbackQuery, user: User) -> None:
    lang = cb.data.split(":", 1)[1]
    if lang not in LANGS:
        await cb.answer()
        return
    user.language = lang
    await cb.message.edit_text(t(lang, "lang_saved"))
    if user.timezone is None:  # продолжаем онбординг
        await cb.message.answer(t(lang, "ask_tz"), reply_markup=kb.timezone_kb(lang))
    await cb.answer()


async def _apply_timezone(message: Message, state: FSMContext, user: User, tz_name: str) -> None:
    first_time = user.timezone is None
    user.timezone = tz_name
    await state.clear()
    now = local_now(tz_name).strftime("%H:%M")
    await message.answer(t(user.language, "tz_saved", tz=tz_name, time=now))
    if first_time:
        await message.answer(t(user.language, "welcome"), reply_markup=kb.goal_kb(user.language))


@router.callback_query(F.data.startswith("tz:"))
async def on_timezone_button(cb: CallbackQuery, state: FSMContext, user: User) -> None:
    value = cb.data.split(":", 1)[1]
    if value == "other":
        await state.set_state(Onboarding.timezone)
        await cb.message.answer(t(user.language, "tz_other_prompt"))
        await cb.answer()
        return
    tz_name = parse_timezone(value)
    if tz_name is None:
        await cb.answer(t(user.language, "error_generic"), show_alert=True)
        return
    await cb.answer()
    await _apply_timezone(cb.message, state, user, tz_name)


@router.message(Onboarding.timezone, F.text)
async def on_timezone_text(message: Message, state: FSMContext, user: User) -> None:
    tz_name = parse_timezone(message.text)
    if tz_name is None:
        await message.answer(t(user.language, "tz_bad"))
        return
    await _apply_timezone(message, state, user, tz_name)
