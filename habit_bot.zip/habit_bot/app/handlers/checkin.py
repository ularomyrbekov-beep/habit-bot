"""/today (чек-ин) и /progress (серии и статистика за неделю)."""
from __future__ import annotations

import logging

from aiogram import F, Router
from aiogram.enums import ChatAction
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message
from sqlalchemy.ext.asyncio import AsyncSession

from app import keyboards as kb
from app.db import repo
from app.db.models import User
from app.i18n import t
from app.services.coach import Coach
from app.services.context import build_user_stats
from app.services.stats import KIND_ICON, STATUS_ICON, compute_stats
from app.utils import local_today

logger = logging.getLogger(__name__)
router = Router(name="checkin")

CODE_TO_STATUS = {"d": "done", "p": "partial", "f": "fail"}


@router.message(Command("today"))
async def cmd_today(message: Message, state: FSMContext, session: AsyncSession, user: User) -> None:
    await state.clear()
    lang = user.language
    if user.timezone is None:
        await message.answer(t(lang, "need_start"))
        return
    habits = await repo.list_habits(session, user.id)
    if not habits:
        await message.answer(t(lang, "no_habits"))
        return
    marked = await repo.get_checkins_for_day(session, [h.id for h in habits], local_today(user.timezone))
    for h in habits:
        status = marked.get(h.id)
        if status:
            text = t(lang, "checkin_q_marked", icon=KIND_ICON[h.kind], title=h.title, status=t(lang, f"st_{status}"))
        else:
            text = t(lang, "checkin_q", icon=KIND_ICON[h.kind], title=h.title)
        await message.answer(text, reply_markup=kb.checkin_kb(lang, h.id))


@router.callback_query(F.data.startswith("ci:"))
async def on_checkin(cb: CallbackQuery, session: AsyncSession, user: User, coach: Coach) -> None:
    lang = user.language
    try:
        _, habit_id, code = cb.data.split(":")
        status = CODE_TO_STATUS[code]
        habit = await repo.get_habit(session, user.id, int(habit_id))
    except (ValueError, KeyError):
        habit = None
    if habit is None or user.timezone is None:
        await cb.answer(t(lang, "habit_gone"), show_alert=True)
        return
    await cb.answer()

    today = local_today(user.timezone)
    await repo.upsert_checkin(session, habit.id, today, status)
    history = await repo.get_checkin_map(session, habit.id)
    stats = compute_stats(habit, history, today)

    await cb.message.edit_text(
        t(lang, "checkin_saved", icon=STATUS_ICON[status], title=habit.title, status=t(lang, f"st_{status}"))
    )
    if status == "done":
        await cb.message.answer(t(lang, "done_reply", streak=stats.streak))
    elif status == "partial":
        await cb.message.answer(t(lang, "partial_reply", streak=stats.streak))
    else:
        # Срыв: мягкий разбор от ИИ-коуча (без осуждения), с запасным текстом на случай сбоя
        answer = None
        if coach.allow(user.id):
            await cb.bot.send_chat_action(cb.message.chat.id, ChatAction.TYPING)
            all_stats = await build_user_stats(session, user)
            answer = await coach.reply(user, all_stats, t(lang, "fail_event", title=habit.title))
        await cb.message.answer(answer or t(lang, "fail_fallback"))


@router.message(Command("progress"))
async def cmd_progress(message: Message, state: FSMContext, session: AsyncSession, user: User) -> None:
    await state.clear()
    lang = user.language
    stats = await build_user_stats(session, user)
    if not stats:
        await message.answer(t(lang, "no_habits") if user.timezone else t(lang, "need_start"))
        return
    blocks = [t(lang, "progress_title")]
    for s in stats:
        blocks.append(
            t(
                lang, "progress_item",
                icon=KIND_ICON[s.habit.kind], title=s.habit.title,
                streak=s.streak, best=s.best, strip=s.strip,
                done=s.done, partial=s.partial, fail=s.fail,
            )
        )
    blocks.append(t(lang, "progress_legend"))
    await message.answer("\n\n".join(blocks))
