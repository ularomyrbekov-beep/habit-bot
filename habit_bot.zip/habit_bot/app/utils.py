"""Небольшие утилиты: время, часовые пояса, очистка текста."""
from __future__ import annotations

import re
from datetime import date, datetime
from zoneinfo import ZoneInfo

_TIME_RE = re.compile(r"^(\d{1,2})(?:[:.](\d{2}))?$")
_OFFSET_RE = re.compile(r"^(?:utc|gmt)?\s*([+-])?\s*(\d{1,2})(?::?00)?$", re.IGNORECASE)


def _zone_exists(name: str) -> bool:
    try:
        ZoneInfo(name)
        return True
    except Exception:  # неверное имя, каталог вместо файла и т.п.
        return False


def parse_timezone(raw: str) -> str | None:
    """Принимает 'Asia/Bishkek', '+6', 'UTC+3', '-5'. Возвращает IANA-имя или None.

    Смещение превращается в Etc/GMT∓N (знак в Etc/GMT инвертирован: Etc/GMT-6 == UTC+6).
    Дробные смещения (+5:30) не поддерживаются - для них нужно имя зоны (Asia/Kolkata).
    """
    s = raw.strip()
    if not s:
        return None
    m = _OFFSET_RE.match(s)
    if m:
        sign = m.group(1) or "+"
        hours = int(m.group(2))
        if hours == 0:
            return "UTC"
        name = f"Etc/GMT{'-' if sign == '+' else '+'}{hours}"
        return name if _zone_exists(name) else None
    for candidate in (s, s.replace(" ", "_"), s.replace(" ", "_").title()):
        if _zone_exists(candidate):
            return candidate
    return None


def parse_time(raw: str) -> str | None:
    """'9', '9:30', '21.00' -> 'HH:MM' или None."""
    m = _TIME_RE.match(raw.strip())
    if not m:
        return None
    hours, minutes = int(m.group(1)), int(m.group(2) or 0)
    if hours > 23 or minutes > 59:
        return None
    return f"{hours:02d}:{minutes:02d}"


def clean_text(raw: str | None, limit: int) -> str | None:
    """Обрезает пробелы; None, если пусто или длиннее лимита."""
    if raw is None:
        return None
    text = " ".join(raw.split())
    if not text or len(text) > limit:
        return None
    return text


def local_now(tz_name: str) -> datetime:
    return datetime.now(ZoneInfo(tz_name))


def local_today(tz_name: str) -> date:
    return local_now(tz_name).date()
