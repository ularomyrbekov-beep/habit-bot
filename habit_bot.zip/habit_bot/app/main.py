"""Точка входа: python -m app.main"""
from __future__ import annotations

import asyncio
import logging
from pathlib import Path

from aiogram import Bot, Dispatcher, F
from aiogram.enums import ChatType
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.types import BotCommand, ErrorEvent

from app.config import load_settings
from app.db.session import create_db, init_db
from app.handlers import chat, checkin, habits, settings as settings_handlers, start, tips
from app.i18n import t
from app.middlewares import DbMiddleware
from app.services.coach import Coach
from app.services.scheduler import setup_scheduler

logger = logging.getLogger(__name__)

COMMAND_KEYS = ["start", "new", "today", "progress", "tips", "habits", "settings", "cancel"]


async def set_commands(bot: Bot) -> None:
    """Меню команд: по умолчанию русское, для клиентов с английским языком - английское."""
    for lang, language_code in (("ru", None), ("en", "en")):
        commands = [BotCommand(command=c, description=t(lang, f"cmd_{c}")) for c in COMMAND_KEYS]
        await bot.set_my_commands(commands, language_code=language_code)


async def on_error(event: ErrorEvent) -> bool:
    """Глобальный перехват ошибок: логируем и вежливо сообщаем пользователю."""
    logger.exception("Необработанная ошибка в хендлере", exc_info=event.exception)
    update = event.update
    try:
        if update.message:
            await update.message.answer("⚠️ Что-то пошло не так / Something went wrong")
        elif update.callback_query:
            await update.callback_query.answer("⚠️ Error", show_alert=True)
    except Exception:
        pass
    return True


async def main() -> None:
    settings = load_settings()
    logging.basicConfig(level=settings.log_level, format="%(asctime)s %(levelname)s %(name)s: %(message)s")

    Path("data").mkdir(exist_ok=True)
    engine, sessionmaker = create_db(settings.database_url)
    await init_db(engine)

    coach = Coach(settings.anthropic_api_key, settings.claude_model, settings.daily_ai_limit)
    bot = Bot(settings.bot_token)  # без parse_mode: пользовательский текст не требует экранирования
    # MemoryStorage: состояния диалогов теряются при перезапуске. Для прода - RedisStorage.
    dp = Dispatcher(storage=MemoryStorage(), coach=coach, settings=settings)

    dp.message.filter(F.chat.type == ChatType.PRIVATE)  # бот работает только в личных чатах
    middleware = DbMiddleware(sessionmaker)
    dp.message.middleware(middleware)
    dp.callback_query.middleware(middleware)

    # Порядок важен: команды и состояния - раньше свободного чата
    for router in (start.router, settings_handlers.router, checkin.router, tips.router, habits.router, chat.router):
        dp.include_router(router)
    dp.errors.register(on_error)

    await set_commands(bot)
    scheduler = setup_scheduler(bot, sessionmaker)
    scheduler.start()
    logger.info("Бот запущен")
    try:
        await dp.start_polling(bot, allowed_updates=dp.resolve_used_update_types())
    finally:
        scheduler.shutdown(wait=False)
        await bot.session.close()
        await engine.dispose()


if __name__ == "__main__":
    asyncio.run(main())
