"""Конфигурация из переменных окружения (.env)."""
from __future__ import annotations

import os
from dataclasses import dataclass

from dotenv import load_dotenv


@dataclass(frozen=True)
class Settings:
    bot_token: str
    anthropic_api_key: str
    claude_model: str
    database_url: str
    max_habits: int
    daily_ai_limit: int
    log_level: str


def _required(name: str) -> str:
    value = os.getenv(name, "").strip()
    if not value:
        raise RuntimeError(f"Переменная окружения {name} не задана. См. .env.example")
    return value


def load_settings() -> Settings:
    load_dotenv()
    return Settings(
        bot_token=_required("BOT_TOKEN"),
        anthropic_api_key=_required("ANTHROPIC_API_KEY"),
        claude_model=os.getenv("CLAUDE_MODEL", "claude-sonnet-5-5"),
        database_url=os.getenv("DATABASE_URL", "sqlite+aiosqlite:///./data/habit.db"),
        max_habits=int(os.getenv("MAX_HABITS", "5")),
        daily_ai_limit=int(os.getenv("DAILY_AI_LIMIT", "40")),
        log_level=os.getenv("LOG_LEVEL", "INFO"),
    )
