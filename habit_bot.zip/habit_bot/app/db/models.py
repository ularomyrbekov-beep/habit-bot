"""Схема БД: пользователи, привычки, чек-ины."""
from __future__ import annotations

from datetime import date, datetime, timezone

from sqlalchemy import BigInteger, Boolean, Date, DateTime, ForeignKey, String, UniqueConstraint
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column


def _utcnow() -> datetime:
    return datetime.now(timezone.utc).replace(tzinfo=None)


class Base(DeclarativeBase):
    pass


class User(Base):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(primary_key=True)
    tg_id: Mapped[int] = mapped_column(BigInteger, unique=True, index=True)
    language: Mapped[str] = mapped_column(String(5), default="ru")
    # IANA-имя пояса; None = пользователь ещё не прошёл онбординг
    timezone: Mapped[str | None] = mapped_column(String(64), nullable=True)
    is_blocked: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_utcnow)


class Habit(Base):
    __tablename__ = "habits"

    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    kind: Mapped[str] = mapped_column(String(8))  # 'quit' | 'build'
    title: Mapped[str] = mapped_column(String(100))
    trigger: Mapped[str] = mapped_column(String(200))  # триггер (quit) или якорь (build)
    action: Mapped[str] = mapped_column(String(200))  # замена (quit) или мини-шаг (build)
    reward: Mapped[str | None] = mapped_column(String(200), nullable=True)
    remind_time: Mapped[str | None] = mapped_column(String(5), nullable=True)  # 'HH:MM' локальное
    last_reminded: Mapped[date | None] = mapped_column(Date, nullable=True)
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_utcnow)


class CheckIn(Base):
    __tablename__ = "checkins"
    __table_args__ = (UniqueConstraint("habit_id", "day", name="uq_checkin_habit_day"),)

    id: Mapped[int] = mapped_column(primary_key=True)
    habit_id: Mapped[int] = mapped_column(ForeignKey("habits.id", ondelete="CASCADE"), index=True)
    day: Mapped[date] = mapped_column(Date)  # локальная дата пользователя
    status: Mapped[str] = mapped_column(String(8))  # 'done' | 'partial' | 'fail'
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_utcnow)
