"""Подключение к БД."""
from __future__ import annotations

from sqlalchemy.ext.asyncio import AsyncEngine, AsyncSession, async_sessionmaker, create_async_engine

from app.db.models import Base


def create_db(url: str) -> tuple[AsyncEngine, async_sessionmaker[AsyncSession]]:
    engine = create_async_engine(url, echo=False, pool_pre_ping=True)
    # expire_on_commit=False: объекты остаются доступными после commit (важно для async)
    return engine, async_sessionmaker(engine, expire_on_commit=False)


async def init_db(engine: AsyncEngine) -> None:
    """Создаёт таблицы, если их нет. Для миграций в проде подключите Alembic."""
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
