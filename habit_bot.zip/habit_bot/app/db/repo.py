"""Доступ к данным: все запросы в одном месте."""
from __future__ import annotations

from datetime import date

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.models import CheckIn, Habit, User


async def get_or_create_user(session: AsyncSession, tg_id: int) -> User:
    user = (await session.execute(select(User).where(User.tg_id == tg_id))).scalar_one_or_none()
    if user is None:
        user = User(tg_id=tg_id)
        session.add(user)
        await session.flush()
    return user


async def count_active_habits(session: AsyncSession, user_id: int) -> int:
    q = select(func.count()).select_from(Habit).where(Habit.user_id == user_id, Habit.active.is_(True))
    return (await session.execute(q)).scalar_one()


async def list_habits(session: AsyncSession, user_id: int) -> list[Habit]:
    q = select(Habit).where(Habit.user_id == user_id, Habit.active.is_(True)).order_by(Habit.id)
    return list((await session.execute(q)).scalars())


async def get_habit(session: AsyncSession, user_id: int, habit_id: int) -> Habit | None:
    q = select(Habit).where(Habit.id == habit_id, Habit.user_id == user_id, Habit.active.is_(True))
    return (await session.execute(q)).scalar_one_or_none()


async def create_habit(session: AsyncSession, **fields) -> Habit:
    habit = Habit(**fields)
    session.add(habit)
    await session.flush()
    return habit


async def get_checkin_map(session: AsyncSession, habit_id: int) -> dict[date, str]:
    q = select(CheckIn.day, CheckIn.status).where(CheckIn.habit_id == habit_id)
    return {day: status for day, status in (await session.execute(q)).all()}


async def get_checkins_for_day(session: AsyncSession, habit_ids: list[int], day: date) -> dict[int, str]:
    if not habit_ids:
        return {}
    q = select(CheckIn.habit_id, CheckIn.status).where(CheckIn.habit_id.in_(habit_ids), CheckIn.day == day)
    return {hid: status for hid, status in (await session.execute(q)).all()}


async def upsert_checkin(session: AsyncSession, habit_id: int, day: date, status: str) -> None:
    q = select(CheckIn).where(CheckIn.habit_id == habit_id, CheckIn.day == day)
    checkin = (await session.execute(q)).scalar_one_or_none()
    if checkin:
        checkin.status = status
    else:
        session.add(CheckIn(habit_id=habit_id, day=day, status=status))
    await session.flush()


async def list_reminder_candidates(session: AsyncSession) -> list[tuple[Habit, User]]:
    """Все активные привычки с напоминанием у пользователей, которые не заблокировали бота."""
    q = (
        select(Habit, User)
        .join(User, User.id == Habit.user_id)
        .where(
            Habit.active.is_(True),
            Habit.remind_time.is_not(None),
            User.timezone.is_not(None),
            User.is_blocked.is_(False),
        )
    )
    return [(h, u) for h, u in (await session.execute(q)).all()]
