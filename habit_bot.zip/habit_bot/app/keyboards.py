"""Inline-клавиатуры."""
from __future__ import annotations

from aiogram.types import InlineKeyboardMarkup
from aiogram.utils.keyboard import InlineKeyboardBuilder

from app.i18n import t

# (ru, en, IANA)
POPULAR_TZ = [
    ("Бишкек", "Bishkek", "Asia/Bishkek"),
    ("Алматы", "Almaty", "Asia/Almaty"),
    ("Ташкент", "Tashkent", "Asia/Tashkent"),
    ("Москва", "Moscow", "Europe/Moscow"),
    ("Киев", "Kyiv", "Europe/Kiev"),
    ("Минск", "Minsk", "Europe/Minsk"),
    ("Лондон", "London", "Europe/London"),
    ("Берлин", "Berlin", "Europe/Berlin"),
    ("Нью-Йорк", "New York", "America/New_York"),
    ("UTC", "UTC", "UTC"),
]


def language_kb() -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    b.button(text="Русский 🇷🇺", callback_data="lang:ru")
    b.button(text="English 🇬🇧", callback_data="lang:en")
    b.adjust(2)
    return b.as_markup()


def timezone_kb(lang: str) -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    for ru, en, tz in POPULAR_TZ:
        b.button(text=ru if lang == "ru" else en, callback_data=f"tz:{tz}")
    b.button(text=t(lang, "btn_tz_other"), callback_data="tz:other")
    b.adjust(2)
    return b.as_markup()


def goal_kb(lang: str) -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    b.button(text=t(lang, "btn_quit"), callback_data="kind:quit")
    b.button(text=t(lang, "btn_build"), callback_data="kind:build")
    b.adjust(1)
    return b.as_markup()


def skip_kb(lang: str, what: str) -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    b.button(text=t(lang, "btn_skip"), callback_data=f"skip:{what}")
    return b.as_markup()


def time_kb(lang: str) -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    for hhmm in ("08:00", "13:00", "20:00", "21:30"):
        b.button(text=hhmm, callback_data=f"time:{hhmm}")
    b.button(text=t(lang, "btn_no_remind"), callback_data="time:off")
    b.adjust(4, 1)
    return b.as_markup()


def checkin_kb(lang: str, habit_id: int) -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    b.button(text=t(lang, "btn_done"), callback_data=f"ci:{habit_id}:d")
    b.button(text=t(lang, "btn_partial"), callback_data=f"ci:{habit_id}:p")
    b.button(text=t(lang, "btn_fail"), callback_data=f"ci:{habit_id}:f")
    b.adjust(1)
    return b.as_markup()


def habit_kb(lang: str, habit_id: int) -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    b.button(text=t(lang, "btn_time"), callback_data=f"htime:{habit_id}")
    b.button(text=t(lang, "btn_delete"), callback_data=f"hdel:{habit_id}")
    b.adjust(2)
    return b.as_markup()


def confirm_delete_kb(lang: str, habit_id: int) -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    b.button(text=t(lang, "btn_yes_delete"), callback_data=f"hdelc:{habit_id}")
    b.button(text=t(lang, "btn_cancel"), callback_data="hcancel")
    b.adjust(2)
    return b.as_markup()


def settings_kb(lang: str) -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    b.button(text=t(lang, "btn_language"), callback_data="set:lang")
    b.button(text=t(lang, "btn_timezone"), callback_data="set:tz")
    b.adjust(2)
    return b.as_markup()


def tips_kb(lang: str) -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    b.button(text=t(lang, "btn_more_tip"), callback_data="tip:more")
    b.button(text=t(lang, "btn_ai_tip"), callback_data="tip:ai")
    b.adjust(1)
    return b.as_markup()
