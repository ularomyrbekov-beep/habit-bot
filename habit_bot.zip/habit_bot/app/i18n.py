"""Тексты интерфейса на русском и английском.

t(lang, key, **kwargs) - получить строку. Если ключа нет в языке, берётся русская версия.
"""
from __future__ import annotations

LANGS = ("ru", "en")
LANG_NAMES = {"ru": "Русский", "en": "English"}

BILINGUAL_GREETING = "Привет! 👋 / Hi! 👋\n\nВыбери язык / Choose your language:"
BILINGUAL_PICK = "Выбери язык / Choose your language:"

STRINGS: dict[str, dict[str, str]] = {
    "ru": {
        # --- онбординг ---
        "lang_saved": "Язык сохранён: Русский ✅",
        "ask_tz": "Теперь выбери часовой пояс — так напоминания придут в удобное для тебя время.",
        "btn_tz_other": "✍️ Другой",
        "tz_other_prompt": "Напиши название пояса, например Asia/Bishkek или Europe/London, либо сдвиг от UTC: +6, -5.",
        "tz_bad": "Не получилось распознать пояс 🤔 Примеры: Asia/Bishkek, Europe/London, +6, -5. Для дробных сдвигов (например, +5:30) используй название, как Asia/Kolkata.",
        "tz_saved": "Часовой пояс сохранён: {tz}. Сейчас у тебя {time}.",
        "welcome": (
            "Я «Привычка» — твой дружелюбный коуч 🌱\n\n"
            "Помогаю избавляться от вредных привычек и заводить полезные: маленькими шагами, "
            "без стыда и давления. Срыв — это нормально, главное — не пропускать дважды.\n\n"
            "С чего начнём?"
        ),
        "welcome_back": (
            "С возвращением! 👋\n\n"
            "/today — чек-ин на сегодня\n"
            "/progress — серия и статистика\n"
            "/new — новая привычка\n"
            "/tips — совет\n"
            "/habits — мои привычки\n"
            "/settings — язык и часовой пояс\n\n"
            "Или просто напиши мне — я на связи как коуч. Что делаем?"
        ),
        "need_start": "Давай сначала познакомимся — нажми /start 🙂",
        "cancelled": "Окей, отменено. Когда будешь готов — /new.",
        "error_generic": "Что-то пошло не так ⚠️ Попробуй ещё раз.",
        # --- новая привычка ---
        "btn_quit": "🚫 Избавиться от привычки",
        "btn_build": "🌱 Завести новую",
        "ask_kind": "Что хочешь сделать?",
        "q_title_quit": "Какую привычку хочешь убрать? Назови коротко, например: «листаю соцсети перед сном».",
        "q_title_build": "Какую привычку хочешь завести? Коротко, например: «зарядка по утрам».",
        "q_trigger_quit": "Когда или после чего это обычно происходит? Это твой триггер. Например: «мне скучно» или «поужинал».",
        "q_trigger_build": "После какого действия, которое ты и так делаешь каждый день, её удобно встроить? Например: «почистил зубы» или «налил утренний кофе».",
        "q_action_quit": "Чем можно заменить это действие? Выбери что-то маленькое на 1–2 минуты. Например: «выпью стакан воды» или «сделаю 5 глубоких вдохов».",
        "q_action_build": "Какой самый маленький вариант этой привычки — на 2 минуты, чтобы получилось даже в плохой день? Например: «сделаю 10 приседаний».",
        "q_reward": "Чем поддержишь себя после? Например: «отмечу в трекере» или «выпью любимый чай». Можно пропустить.",
        "q_remind": "Во сколько напоминать о чек-ине? Напиши время в формате ЧЧ:ММ (например, 21:00) или выбери кнопкой.",
        "btn_skip": "Пропустить",
        "btn_no_remind": "Не напоминать",
        "text_bad": "Получилось пусто или слишком длинно. Давай покороче (до {n} символов).",
        "bad_time": "Не понял время 🤔 Напиши в формате ЧЧ:ММ, например 21:30.",
        "limit_reached": "У тебя уже {n} активных привычек. Чтобы получилось, лучше держать фокус на малом: убери одну в /habits, а потом добавим новую.",
        "remind_off": "выключено",
        "rule_quit": "Если «{trigger}», то {action}.",
        "rule_build": "После «{trigger}» я {action}.",
        "saved": (
            "Готово! 🎉 Привычка добавлена.\n\n"
            "{icon} {title}\n"
            "🔁 {rule}\n"
            "🎁 Награда: {reward}\n"
            "⏰ Напоминание: {remind}\n\n"
            "Начни с малого: один маленький шаг в день — уже победа. Отмечайся в /today. "
            "Срыв — не конец, главное — не пропускать дважды 💛"
        ),
        # --- чек-ин ---
        "no_habits": "Пока нет привычек. Давай добавим первую: /new",
        "btn_done": "✅ Получилось",
        "btn_partial": "🟡 Частично",
        "btn_fail": "❌ Не получилось",
        "st_done": "Получилось",
        "st_partial": "Частично",
        "st_fail": "Не получилось",
        "checkin_q": "{icon} {title}\nКак сегодня?",
        "checkin_q_marked": "{icon} {title}\nСегодня отмечено: {status}. Можешь изменить:",
        "checkin_saved": "{icon} {title} — {status}",
        "done_reply": "Отлично! 🎉 Серия: {streak} дн.",
        "partial_reply": "Частично — это тоже шаг вперёд 🟡 Серия продолжается: {streak} дн. Главное — не пропускать дважды.",
        "fail_fallback": "Бывает, это нормально 💛 Один срыв ничего не отменяет. Давай завтра сделаем шаг ещё меньше. Что обычно происходит прямо перед тем, как не получается?",
        "fail_event": "Отметка в чек-ине за сегодня: «Не получилось» по привычке «{title}». Отреагируй тепло и без осуждения, помоги разобрать триггер и упростить шаг.",
        "habit_gone": "Не нашёл эту привычку — возможно, её уже убрали.",
        # --- прогресс ---
        "progress_title": "📊 Твой прогресс",
        "progress_item": "{icon} {title}\n🔥 Серия: {streak} дн. (рекорд: {best})\nНеделя: {strip}\n✅ {done} · 🟡 {partial} · ❌ {fail} из 7 дней",
        "progress_legend": "✅ получилось · 🟡 частично · ❌ не получилось · ▫️ нет отметки",
        # --- мои привычки ---
        "habit_card": "{icon} {title}\n🔁 {rule}\n⏰ {remind}",
        "btn_time": "⏰ Время",
        "btn_delete": "🗑 Убрать",
        "confirm_delete": "Убрать привычку «{title}»? История сохранится, но чек-ины и напоминания прекратятся.",
        "btn_yes_delete": "Да, убрать",
        "btn_cancel": "Отмена",
        "deleted": "Готово, привычка убрана.",
        "ask_new_time": "Во сколько напоминать про «{title}»? Напиши ЧЧ:ММ или выбери кнопкой.",
        "time_saved": "Готово! Напоминание: {remind} ⏰",
        # --- настройки ---
        "settings_menu": "⚙️ Настройки\n\nЯзык: {lang}\nЧасовой пояс: {tz}",
        "btn_language": "🌐 Язык",
        "btn_timezone": "🕒 Часовой пояс",
        # --- советы ---
        "tip_header": "💡 Совет\n\n{tip}",
        "btn_more_tip": "🔄 Ещё совет",
        "btn_ai_tip": "💬 Для моих привычек",
        "tip_need_habits": "Сначала добавь привычку (/new) — тогда подскажу лично для тебя.",
        "ai_tip_request": "Дай один короткий практический совет именно под мои текущие привычки и серии. Один приём, 2–4 предложения.",
        # --- ИИ-коуч ---
        "ai_error": "Что-то пошло не так, и я не смог ответить 🙏 Попробуй ещё раз чуть позже.",
        "rate_limited": "На сегодня лимит сообщений коучу исчерпан. Продолжим завтра 💛 А /today и /progress работают как обычно.",
        "crisis": (
            "Мне очень жаль, что сейчас так тяжело 💛 То, о чём ты пишешь, очень важно, "
            "и тебе не нужно справляться с этим в одиночку.\n\n"
            "Давай на время отложим привычки. Пожалуйста, прямо сейчас свяжись с близким человеком "
            "или с местной службой экстренной помощи (во многих странах это 112), либо с линией доверия "
            "в твоей стране. Если есть риск, что ты можешь себе навредить, не оставайся один: "
            "позвони или попроси кого-нибудь побыть рядом.\n\n"
            "Живой человек сейчас поможет лучше, чем я. Ты важен."
        ),
        # --- напоминания ---
        "remind_msg": "⏰ Время чек-ина!\n{icon} {title}\nКак сегодня?",
        "remind_streak": "\n\n🔥 Серия: {streak} дн. Так держать!",
        "remind_missed": "\n\nВчера не вышло — это нормально. Сегодня главное — не пропустить дважды 💛",
        # --- команды меню ---
        "cmd_start": "Начать / меню",
        "cmd_new": "Новая привычка",
        "cmd_today": "Чек-ин на сегодня",
        "cmd_progress": "Серия и статистика",
        "cmd_tips": "Совет дня",
        "cmd_habits": "Мои привычки",
        "cmd_settings": "Язык и часовой пояс",
        "cmd_cancel": "Отменить действие",
    },
    "en": {
        "lang_saved": "Language saved: English ✅",
        "ask_tz": "Now pick your time zone, so reminders arrive at the right time for you.",
        "btn_tz_other": "✍️ Other",
        "tz_other_prompt": "Type a zone name like Asia/Bishkek or Europe/London, or an offset from UTC: +6, -5.",
        "tz_bad": "I couldn't recognize that zone 🤔 Examples: Asia/Bishkek, Europe/London, +6, -5. For fractional offsets (e.g. +5:30) use a zone name like Asia/Kolkata.",
        "tz_saved": "Time zone saved: {tz}. Your local time is {time}.",
        "welcome": (
            "I'm Habit — your friendly coach 🌱\n\n"
            "I help you drop unhelpful habits and build good ones: in tiny steps, with no shame "
            "or pressure. Slips are normal — the key is never to miss twice.\n\n"
            "Where shall we start?"
        ),
        "welcome_back": (
            "Welcome back! 👋\n\n"
            "/today — today's check-in\n"
            "/progress — streaks and stats\n"
            "/new — new habit\n"
            "/tips — a tip\n"
            "/habits — my habits\n"
            "/settings — language and time zone\n\n"
            "Or just write to me — I'm here as your coach. What shall we do?"
        ),
        "need_start": "Let's get acquainted first — tap /start 🙂",
        "cancelled": "Okay, cancelled. When you're ready — /new.",
        "error_generic": "Something went wrong ⚠️ Please try again.",
        "btn_quit": "🚫 Quit a habit",
        "btn_build": "🌱 Build a new one",
        "ask_kind": "What would you like to do?",
        "q_title_quit": "Which habit do you want to drop? Keep it short, e.g. \"scrolling social media before bed\".",
        "q_title_build": "Which habit do you want to build? Keep it short, e.g. \"morning stretching\".",
        "q_trigger_quit": "When or after what does it usually happen? That's your trigger. E.g. \"I'm bored\" or \"finished dinner\".",
        "q_trigger_build": "After which thing you already do every day could this fit? E.g. \"brush my teeth\" or \"pour my morning coffee\".",
        "q_action_quit": "What could you do instead? Pick something tiny, 1–2 minutes. E.g. \"drink a glass of water\" or \"take 5 deep breaths\".",
        "q_action_build": "What's the tiniest version of this habit — 2 minutes, doable even on a bad day? E.g. \"do 10 squats\".",
        "q_reward": "How will you treat yourself afterwards? E.g. \"tick it in the tracker\" or \"have my favorite tea\". You can skip this.",
        "q_remind": "What time should I remind you to check in? Type HH:MM (e.g. 21:00) or tap a button.",
        "btn_skip": "Skip",
        "btn_no_remind": "No reminders",
        "text_bad": "That came out empty or too long. Let's keep it shorter (up to {n} characters).",
        "bad_time": "I didn't get the time 🤔 Use HH:MM, e.g. 21:30.",
        "limit_reached": "You already have {n} active habits. To make it work, keep the focus small: remove one in /habits, then we'll add a new one.",
        "remind_off": "off",
        "rule_quit": "If \"{trigger}\", then {action}.",
        "rule_build": "After \"{trigger}\", I {action}.",
        "saved": (
            "Done! 🎉 Habit added.\n\n"
            "{icon} {title}\n"
            "🔁 {rule}\n"
            "🎁 Reward: {reward}\n"
            "⏰ Reminder: {remind}\n\n"
            "Start small: one tiny step a day is already a win. Check in with /today. "
            "A slip isn't the end — just don't miss twice 💛"
        ),
        "no_habits": "No habits yet. Let's add your first: /new",
        "btn_done": "✅ Did it",
        "btn_partial": "🟡 Partly",
        "btn_fail": "❌ Didn't work out",
        "st_done": "Did it",
        "st_partial": "Partly",
        "st_fail": "Didn't work out",
        "checkin_q": "{icon} {title}\nHow was today?",
        "checkin_q_marked": "{icon} {title}\nMarked today: {status}. You can change it:",
        "checkin_saved": "{icon} {title} — {status}",
        "done_reply": "Great! 🎉 Streak: {streak} days.",
        "partial_reply": "Partly is still a step forward 🟡 Your streak goes on: {streak} days. Just don't miss twice.",
        "fail_fallback": "It happens, and it's okay 💛 One slip cancels nothing. Let's make tomorrow's step even smaller. What usually happens right before it doesn't work out?",
        "fail_event": "Today's check-in mark: \"Didn't work out\" for the habit \"{title}\". Respond warmly and without judgment, help me find the trigger and simplify the step.",
        "habit_gone": "I couldn't find that habit — it may have been removed.",
        "progress_title": "📊 Your progress",
        "progress_item": "{icon} {title}\n🔥 Streak: {streak} days (best: {best})\nWeek: {strip}\n✅ {done} · 🟡 {partial} · ❌ {fail} of 7 days",
        "progress_legend": "✅ did it · 🟡 partly · ❌ didn't work out · ▫️ no mark",
        "habit_card": "{icon} {title}\n🔁 {rule}\n⏰ {remind}",
        "btn_time": "⏰ Time",
        "btn_delete": "🗑 Remove",
        "confirm_delete": "Remove the habit \"{title}\"? History stays, but check-ins and reminders stop.",
        "btn_yes_delete": "Yes, remove",
        "btn_cancel": "Cancel",
        "deleted": "Done, the habit is removed.",
        "ask_new_time": "What time should I remind you about \"{title}\"? Type HH:MM or tap a button.",
        "time_saved": "Done! Reminder: {remind} ⏰",
        "settings_menu": "⚙️ Settings\n\nLanguage: {lang}\nTime zone: {tz}",
        "btn_language": "🌐 Language",
        "btn_timezone": "🕒 Time zone",
        "tip_header": "💡 Tip\n\n{tip}",
        "btn_more_tip": "🔄 Another tip",
        "btn_ai_tip": "💬 For my habits",
        "tip_need_habits": "Add a habit first (/new) — then I can give you a personal tip.",
        "ai_tip_request": "Give me one short practical tip tailored to my current habits and streaks. One technique, 2–4 sentences.",
        "ai_error": "Something went wrong and I couldn't answer 🙏 Please try again a bit later.",
        "rate_limited": "You've reached today's message limit with the coach. Let's continue tomorrow 💛 /today and /progress work as usual.",
        "crisis": (
            "I'm so sorry things feel this heavy right now 💛 What you're writing about matters a lot, "
            "and you don't have to deal with it alone.\n\n"
            "Let's set habits aside for now. Please reach out right away to someone close to you, "
            "or to your local emergency services (112 in many countries), or a crisis line in your country. "
            "If there's a risk you might hurt yourself, please don't stay alone: call someone or ask "
            "a person to be with you.\n\n"
            "A real person can help you better right now than I can. You matter."
        ),
        "remind_msg": "⏰ Check-in time!\n{icon} {title}\nHow was today?",
        "remind_streak": "\n\n🔥 Streak: {streak} days. Keep it up!",
        "remind_missed": "\n\nYesterday didn't work out — that's okay. Today the key is not to miss twice 💛",
        "cmd_start": "Start / menu",
        "cmd_new": "New habit",
        "cmd_today": "Today's check-in",
        "cmd_progress": "Streaks and stats",
        "cmd_tips": "A tip",
        "cmd_habits": "My habits",
        "cmd_settings": "Language and time zone",
        "cmd_cancel": "Cancel current action",
    },
}

TIPS: dict[str, list[str]] = {
    "ru": [
        "Начни с шага на 2 минуты. Если он кажется смешно маленьким — отлично, значит, ты точно его сделаешь.",
        "Формула «После [действие] я [привычка]»: привяжи новое к тому, что ты и так делаешь каждый день.",
        "Формула «Если [триггер], то [действие]»: заранее реши, что сделаешь вместо привычного срыва.",
        "Не пропускай дважды. Один пропуск — случайность, два подряд — начало новой привычки. Возвращайся на следующий же день.",
        "Сделай вредную привычку неудобной: убери из поля зрения и добавь 1–2 лишних шага до неё.",
        "Сделай полезную привычку заметной: кроссовки у двери, стакан воды на столе, книга на подушке.",
        "Сразу отмечай маленькую победу. Галочка в /today — тоже награда для мозга.",
        "Срыв — это данные, а не приговор. Спроси себя: что было прямо перед этим? Это и есть твой триггер.",
        "Не меняй всё сразу. Одна-две привычки одновременно — реалистичный объём.",
        "Если сегодня тяжело — сделай версию на 10% от плана. Серия важнее идеальности.",
    ],
    "en": [
        "Start with a 2-minute step. If it feels laughably small — great, that means you'll actually do it.",
        "Try \"After [action], I [habit]\": attach the new thing to something you already do every day.",
        "Try \"If [trigger], then [action]\": decide in advance what you'll do instead of the usual slip.",
        "Never miss twice. One miss is an accident, two in a row is the start of a new habit. Come back the very next day.",
        "Make the unhelpful habit inconvenient: take it out of sight and add 1–2 extra steps before it.",
        "Make the good habit obvious: sneakers by the door, a glass of water on the desk, a book on the pillow.",
        "Celebrate the small win right away. A tick in /today is a reward for your brain, too.",
        "A slip is data, not a verdict. Ask yourself: what happened right before? That's your trigger.",
        "Don't change everything at once. One or two habits at a time is a realistic load.",
        "If today is hard, do a 10% version of the plan. Streaks beat perfection.",
    ],
}


def t(lang: str, key: str, /, **kwargs: object) -> str:
    """Возвращает строку на языке lang (запасной вариант - русский)."""
    template = STRINGS.get(lang, STRINGS["ru"]).get(key) or STRINGS["ru"][key]
    return template.format(**kwargs) if kwargs else template
