"""Состояния FSM для пошаговых диалогов."""
from aiogram.fsm.state import State, StatesGroup


class Onboarding(StatesGroup):
    timezone = State()


class NewHabit(StatesGroup):
    title = State()
    trigger = State()
    action = State()
    reward = State()
    remind = State()


class EditHabit(StatesGroup):
    time = State()
