"""Сбор статистики по всем привычкам пользователя (для /progress, ИИ-коуча, напоминаний)."""
from __future__ import annotations

from sqlalchemy.ext.asyncio import AsyncSession

from app.db import repo
from app.db.models import User
from app.services.stats import HabitStats, compute_stats
from app.utils import local_today


async def build_user_stats(session: AsyncSession, user: User) -> list[HabitStats]:
    if not user.timezone:
        return []
    today = local_today(user.timezone)
    result: list[HabitStats] = []
    for habit in await repo.list_habits(session, user.id):
        history = await repo.get_checkin_map(session, habit.id)
        result.append(compute_stats(habit, history, today))
    return result
