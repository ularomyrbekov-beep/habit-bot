"""Серии и статистика. Чистые функции без обращения к БД - легко тестировать.

Правила:
- «Получилось» и «Частично» продолжают серию, «Не получилось» её обрывает.
- Если сегодня отметки ещё нет, серия считается от вчера (день не потерян, пока не закончился).
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import date, timedelta
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from app.db.models import Habit

GOOD = {"done", "partial"}
STATUS_ICON = {"done": "✅", "partial": "🟡", "fail": "❌"}
EMPTY_ICON = "▫️"
KIND_ICON = {"quit": "🚫", "build": "🌱"}


@dataclass
class HabitStats:
    habit: "Habit"
    streak: int
    best: int
    strip: str  # 7 иконок: от старых дней к сегодняшнему
    done: int
    partial: int
    fail: int
    missed_yesterday: bool


def current_streak(history: dict[date, str], today: date) -> int:
    day = today if today in history else today - timedelta(days=1)
    streak = 0
    while history.get(day) in GOOD:
        streak += 1
        day -= timedelta(days=1)
    return streak


def best_streak(history: dict[date, str]) -> int:
    best = run = 0
    prev: date | None = None
    for day in sorted(d for d, s in history.items() if s in GOOD):
        run = run + 1 if prev is not None and day - prev == timedelta(days=1) else 1
        best = max(best, run)
        prev = day
    return best


def compute_stats(habit: "Habit", history: dict[date, str], today: date) -> HabitStats:
    last7 = [today - timedelta(days=i) for i in range(6, -1, -1)]
    statuses = [history.get(d) for d in last7]
    yesterday = today - timedelta(days=1)
    # «не пропускай дважды»: вчера не вышло/не отмечено (если привычка старше вчерашнего дня)
    missed = habit.created_at.date() < yesterday and history.get(yesterday) not in GOOD
    return HabitStats(
        habit=habit,
        streak=current_streak(history, today),
        best=best_streak(history),
        strip="".join(STATUS_ICON.get(s, EMPTY_ICON) for s in statuses),
        done=statuses.count("done"),
        partial=statuses.count("partial"),
        fail=statuses.count("fail"),
        missed_yesterday=missed,
    )
