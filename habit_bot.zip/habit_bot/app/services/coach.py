"""ИИ-коуч на Claude API: системный промпт + контекст пользователя + короткая история диалога."""
from __future__ import annotations

import logging
from collections import defaultdict, deque
from datetime import date
from pathlib import Path

import anthropic

from app.db.models import User
from app.services.stats import HabitStats

logger = logging.getLogger(__name__)

PROMPT_PATH = Path(__file__).resolve().parent.parent / "prompts" / "coach_system.md"
HISTORY_LEN = 12  # сообщений (6 пар); чётное число, чтобы история начиналась с реплики пользователя


class Coach:
    def __init__(self, api_key: str, model: str, daily_limit: int) -> None:
        self._client = anthropic.AsyncAnthropic(api_key=api_key, timeout=30.0, max_retries=2)
        self._model = model
        self._daily_limit = daily_limit
        self._base_prompt = PROMPT_PATH.read_text(encoding="utf-8")
        # История в памяти процесса: после перезапуска обнуляется (см. идеи развития)
        self._history: dict[int, deque[dict[str, str]]] = defaultdict(lambda: deque(maxlen=HISTORY_LEN))
        self._usage: dict[int, tuple[date, int]] = {}

    def allow(self, user_id: int) -> bool:
        """Простой суточный лимит обращений к модели на пользователя."""
        today = date.today()
        day, count = self._usage.get(user_id, (today, 0))
        if day != today:
            day, count = today, 0
        if count >= self._daily_limit:
            return False
        self._usage[user_id] = (day, count + 1)
        return True

    @staticmethod
    def _format_context(user: User, stats: list[HabitStats]) -> str:
        lines = [
            f"Язык ответа: {'русский' if user.language == 'ru' else 'English'}",
            f"Сегодня: {date.today().isoformat()}",
            "Текущие привычки пользователя:",
        ]
        if not stats:
            lines.append("(пока нет ни одной привычки)")
        for i, s in enumerate(stats, 1):
            h = s.habit
            kind = "избавиться от привычки" if h.kind == "quit" else "завести привычку"
            lines.append(
                f"{i}. [{kind}] «{h.title}»; "
                f"{'триггер' if h.kind == 'quit' else 'якорь'}: «{h.trigger}»; "
                f"{'замена' if h.kind == 'quit' else 'мини-шаг'}: «{h.action}»; "
                f"награда: {h.reward or 'не задана'}; "
                f"серия: {s.streak} дн.; рекорд: {s.best}; "
                f"последние 7 дней (от старых к новым): {s.strip}; "
                f"вчера пропущено: {'да' if s.missed_yesterday else 'нет'}"
            )
        return "\n".join(lines)

    async def reply(self, user: User, stats: list[HabitStats], text: str) -> str | None:
        """Ответ коуча или None, если API недоступен (вызывающий код покажет запасной текст)."""
        system = f"{self._base_prompt}\n\n<user_context>\n{self._format_context(user, stats)}\n</user_context>"
        history = self._history[user.id]
        messages = list(history)
        while messages and messages[0]["role"] != "user":
            messages.pop(0)
        messages.append({"role": "user", "content": text})
        try:
            response = await self._client.messages.create(
                model=self._model, max_tokens=500, system=system, messages=messages
            )
        except anthropic.APIError as exc:
            logger.warning("Claude API error: %s", exc)
            return None
        answer = "".join(b.text for b in response.content if b.type == "text").strip()
        if not answer:
            return None
        history.append({"role": "user", "content": text})
        history.append({"role": "assistant", "content": answer})
        return answer
