"""Планировщик напоминаний (APScheduler).

Раз в минуту проверяем все привычки с напоминанием. Привычка «созрела», если локальное время
пользователя уже наступило (но прошло не больше REMIND_WINDOW_MIN минут), сегодня её ещё не
напоминали и чек-ина за сегодня нет. Окно в 30 минут переживает рестарты и задержки.
"""
from __future__ import annotations

import asyncio
import logging

from aiogram import Bot
from aiogram.exceptions import TelegramAPIError, TelegramForbiddenError, TelegramRetryAfter
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker

from app import keyboards as kb
from app.db import repo
from app.db.models import User
from app.i18n import t
from app.services.stats import KIND_ICON, compute_stats
from app.utils import local_now

logger = logging.getLogger(__name__)
REMIND_WINDOW_MIN = 30


async def _send(bot: Bot, user: User, text: str, markup) -> bool:
    for _ in range(2):
        try:
            await bot.send_message(user.tg_id, text, reply_markup=markup)
            return True
        except TelegramRetryAfter as exc:
            await asyncio.sleep(exc.retry_after)
        except TelegramForbiddenError:
            user.is_blocked = True  # пользователь заблокировал бота - больше не пишем
            return False
        except TelegramAPIError as exc:
            logger.warning("Не удалось отправить напоминание %s: %s", user.tg_id, exc)
            return False
    return False


async def send_due_reminders(bot: Bot, sessionmaker: async_sessionmaker[AsyncSession]) -> None:
    async with sessionmaker() as session:
        try:
            for habit, user in await repo.list_reminder_candidates(session):
                try:
                    now = local_now(user.timezone)
                    hours, minutes = map(int, habit.remind_time.split(":"))
                except Exception:
                    logger.warning("Некорректные данные напоминания у привычки %s", habit.id)
                    continue
                today = now.date()
                if habit.last_reminded == today:
                    continue
                diff = now.hour * 60 + now.minute - (hours * 60 + minutes)
                if not 0 <= diff < REMIND_WINDOW_MIN:
                    continue

                history = await repo.get_checkin_map(session, habit.id)
                habit.last_reminded = today
                if today not in history:  # уже отмечено - не беспокоим
                    stats = compute_stats(habit, history, today)
                    text = t(user.language, "remind_msg", icon=KIND_ICON[habit.kind], title=habit.title)
                    if stats.missed_yesterday:
                        text += t(user.language, "remind_missed")
                    elif stats.streak:
                        text += t(user.language, "remind_streak", streak=stats.streak)
                    await _send(bot, user, text, kb.checkin_kb(user.language, habit.id))
                    await asyncio.sleep(0.05)  # бережём лимиты Telegram (~30 сообщений/сек)
                await session.commit()
        except Exception:
            logger.exception("Ошибка в задаче напоминаний")
            await session.rollback()


def setup_scheduler(bot: Bot, sessionmaker: async_sessionmaker[AsyncSession]) -> AsyncIOScheduler:
    scheduler = AsyncIOScheduler(timezone="UTC")
    scheduler.add_job(
        send_due_reminders,
        trigger="cron",
        second=5,  # каждую минуту на 5-й секунде
        args=[bot, sessionmaker],
        id="reminders",
        max_instances=1,
        coalesce=True,
        misfire_grace_time=30,
    )
    return scheduler
