"""Тесты чистой логики (без Telegram и БД). Запуск: pytest -q  или  python tests/test_logic.py"""
import sys
from datetime import date, datetime, timedelta
from pathlib import Path
from types import SimpleNamespace

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app.services.safety import is_crisis  # noqa: E402
from app.services.stats import best_streak, compute_stats, current_streak  # noqa: E402
from app.utils import clean_text, parse_time, parse_timezone  # noqa: E402

TODAY = date(2026, 11, 10)


def d(n: int) -> date:
    return TODAY - timedelta(days=n)


def test_streak_counts_done_and_partial():
    h = {d(0): "done", d(1): "partial", d(2): "done", d(3): "fail", d(4): "done"}
    assert current_streak(h, TODAY) == 3


def test_streak_not_lost_until_day_ends():
    h = {d(1): "done", d(2): "done"}  # сегодня ещё нет отметки
    assert current_streak(h, TODAY) == 2


def test_fail_today_breaks_streak():
    h = {d(0): "fail", d(1): "done", d(2): "done"}
    assert current_streak(h, TODAY) == 0


def test_best_streak():
    h = {d(10): "done", d(9): "done", d(8): "done", d(6): "done", d(5): "done"}
    assert best_streak(h) == 3


def test_missed_yesterday_rule():
    habit = SimpleNamespace(created_at=datetime(2026, 11, 1))
    assert compute_stats(habit, {d(2): "done"}, TODAY).missed_yesterday is True
    assert compute_stats(habit, {d(1): "partial"}, TODAY).missed_yesterday is False
    fresh = SimpleNamespace(created_at=datetime(2026, 11, 10))
    assert compute_stats(fresh, {}, TODAY).missed_yesterday is False


def test_week_strip_and_counts():
    habit = SimpleNamespace(created_at=datetime(2026, 11, 1))
    s = compute_stats(habit, {d(0): "done", d(1): "fail", d(2): "partial"}, TODAY)
    assert s.strip == "▫️▫️▫️▫️🟡❌✅"
    assert (s.done, s.partial, s.fail) == (1, 1, 1)


def test_parse_time():
    assert parse_time("9") == "09:00"
    assert parse_time("21.30") == "21:30"
    assert parse_time("25:00") is None
    assert parse_time("abc") is None


def test_parse_timezone():
    assert parse_timezone("Asia/Bishkek") == "Asia/Bishkek"
    assert parse_timezone("+6") == "Etc/GMT-6"  # знак в Etc/GMT инвертирован
    assert parse_timezone("UTC-5") == "Etc/GMT+5"
    assert parse_timezone("0") == "UTC"
    assert parse_timezone("Mars/Base") is None
    assert parse_timezone("") is None


def test_clean_text():
    assert clean_text("  привет   мир ", 50) == "привет мир"
    assert clean_text("   ", 50) is None
    assert clean_text("x" * 51, 50) is None


def test_crisis_detection():
    assert is_crisis("Я не хочу больше жить")
    assert is_crisis("I want to die")
    assert not is_crisis("Сорвался, опять залип в телефоне")


if __name__ == "__main__":
    for name, fn in list(globals().items()):
        if name.startswith("test_"):
            fn()
            print("ok", name)
